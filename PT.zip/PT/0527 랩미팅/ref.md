이제 모든 논문 제목을 정리해 드리겠습니다.

---

## 📚 최종본 참고문헌 — 논문 전체 제목 목록

---

### 🔵 프로젝트 내 직접 파일로 존재하는 논문

| # | 저자 (연도) | 논문 전체 제목 | 저널 |
|---|------------|-------------|------|
| 1 | Büttner et al. (2024) | **Bilateral Waveform Analysis of Gait Biomechanics Presurgery to 12 Months Post–Anterior Cruciate Ligament Reconstruction** | *Journal of Orthopaedic Research* |
| 2 | Garcia et al. (2021) | **Gait Asymmetries Are Exacerbated at Faster Walking Speeds in Individuals with Acute Anterior Cruciate Ligament Reconstruction** | *Journal of Orthopaedic Research* |
| 3 | Krishnan et al. (2022) | **Mechanical Factors Underlying Altered Knee Extension Moment in Individuals with Anterior Cruciate Ligament Reconstruction at Three Walking Speeds** | *Journal of Orthopaedic Research* |
| 4 | Lai et al. (2024) | **Whether Patients with Anterior Cruciate Ligament Reconstruction Walking at a Fast Speed Have More Knee Kinematic Asymmetries** | *Orthopaedic Surgery* |
| 5 | Yu et al. (2026) | **Advances in Gait Alterations and Rehabilitation After Anterior Cruciate Ligament Reconstruction** | *Orthopaedic Surgery* |
| 6 | Lisee et al. (2022) | **Linking Gait Biomechanics and Daily Steps Post ACL-Reconstruction** | *Medicine & Science in Sports & Exercise* |
| 7 | Kaur et al. (2016) | **Movement Patterns of the Knee During Gait Following ACL Reconstruction: A Systematic Review and Meta-Analysis** | *Sports Medicine* |
| 8 | Lewek et al. (2002) | **The Effect of Insufficient Quadriceps Strength on Gait After Anterior Cruciate Ligament Reconstruction** | *Clinical Biomechanics* |
| 9 | Yona, Peskin & Fischer (2026) | **The COMPWALK-ACL: A Dataset of Multi-pace IMU Gait Kinematics in Adolescents, Adults, and ACL Injured Patients** | *Scientific Data* |
| 10 | Zhu et al. (2025) | **Multi-modal Gait Analysis for ACL Reconstruction Classification Using IMU Sensors and Machine Learning** | *Smart Health* |
| 11 | Jones et al. (2022) | **Angular Velocities and Linear Accelerations Derived from Inertial Measurement Units Can Be Used as Proxy Measures of Knee Variables Associated with ACL Injury** | *Sensors* |
| 12 | Krishnakumar et al. (2024) | **Estimation of Kinetics Using IMUs to Monitor and Aid in Clinical Decision-Making during ACL Rehabilitation: A Systematic Review** | *Sensors* |
| 13 | Tedesco et al. (2020) | **A Wearable System for Gait Training in Subjects with Anterior Cruciate Ligament Reconstruction** | *Sensors* |
| 14 | Yuan et al. (2026) | **IMU-Based Running Gait Analysis Using Machine Learning and Sensor Fusion** | *Frontiers* |
| 15 | Hall, Stevermer & Gillette (2012) | **Gait Analysis Post Anterior Cruciate Ligament Reconstruction: Knee Osteoarthritis Perspective** | *Gait & Posture* |
| 16 | Mpaliotes, Vasileios (2022) | **Gait Analysis Using IMU Sensors in Patients After Anterior Cruciate Ligament Reconstruction** (그리스어 학위논문) | 학위논문 |
| 17 | Hur et al. (2025) | **Learning Lower-Limb Joint Kinematics from IMU Data Using Transfer Learning** | *Scientific Reports* |
| 18 | Davis-Wilson et al. (2020) | **Bilateral Gait Six and Twelve Months Post–Anterior Cruciate Ligament Reconstruction Compared to Controls** | *Medicine & Science in Sports & Exercise* |

---

### 🟡 본문에서 인용되었으나 프로젝트 파일 외에서 확인 필요한 논문

| # | 저자 (연도) | 논문 전체 제목 | 저널 |
|---|------------|-------------|------|
| 19 | Wellsandt et al. (2016) | **Decreased Knee Joint Loading Associated with Early Knee Osteoarthritis After Anterior Cruciate Ligament Injury** | *American Journal of Sports Medicine* |
| 20 | Di Stasi et al. (2013) | **Gait Patterns Differ Between ACL-Reconstructed Athletes Who Pass Return-to-Sport Criteria and Those Who Fail** | *American Journal of Sports Medicine* |
| 21 | Lee & Park (2020) | **Estimation of Three-Dimensional Lower Limb Kinetics Data during Walking Using Machine Learning from a Single IMU Attached to the Sacrum** | *Sensors* |
| 22 | Sigward et al. (2016) | **Pelvis and Trunk Motion Influence Valgus Knee Loading During Gait in Those with ACL Deficiency** | *Clinical Biomechanics* |

---

### 📌 정리 기준 안내

| 색상 | 의미 |
|------|------|
| 🔵 파란색 | 프로젝트 업로드 파일에 직접 존재 → 인용 정보 확정 가능 |
| 🟡 노란색 | 본문 논리 구성상 인용되었으나 타 논문의 reference list에서 확인된 것 → **최종 제출 전 원문 직접 확인 및 인용번호 부여 필요** |