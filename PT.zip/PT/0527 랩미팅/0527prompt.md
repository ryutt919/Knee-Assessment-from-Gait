당신은 의공학 및 스포츠 재활 분야의 학술 발표 전문가입니다.
아래에 제공된 연구 구조를 바탕으로, 학술 발표(세미나/학회 수준)에 
사용할 수 있는 완성도 높은 슬라이드 내러티브와 구성안을 작성해 주세요.

==================================================
[연구 개요]
==================================================

연구 주제:
  IMU 데이터를 사용한 다속도 보행 분석으로 ACL 환자 판별 및 회복도 측정
  (타겟 저널: Sensors, MDPI)

핵심 연구 질문:
  RQ1. 다속도 IMU 보행 시계열 데이터로 ACLD / ACLR / Healthy 집단을 
       구별할 수 있는가?
  RQ2. 보행 속도 증가 시 비대칭이 증폭되는 패턴이 IMU 데이터에서도 
       재현되는가? (선행 연구 Garcia 2021, Krishnan 2022, Lai 2024 근거)
  RQ3. ACLR 수술 후 3개월 시점의 회복도가 보행 패턴에서 정량화될 수 있는가?

===============================
[서론]
==============================
전방 십자인대(ACL) 손상은 활동적인 인구에서 가장 흔하고 심각한 근골격계 손상 중 하나로, 미국에서만 연간 약 25만 건의 재건술(ACLR)이 시행되는 것으로 추산된다 [REF: Zhu 2025]. 

ACLR은 즉각적인 기능 저하에 그치지 않고 장기적으로도 상당한 임상 부담을 수반한다. 수술 후 2년 이내 재파열률은 15–25%에 달하며, 외상 후 골관절염(post-traumatic osteoarthritis, PTOA)은 손상 후 10–15년 이내에 환자의 최대 50%에서 발생한다 [REF: Yu 2026; Movement Patterns SR]. 

이러한 위험에도 불구하고, 재활 진행 상황과 스포츠 복귀(return-to-sport, RTS) 준비도를 결정하는 임상 기준은 여전히 일관성이 없고 대부분 주관적 판단에 의존하고 있다 [REF: Di Stasi 2012; Quadriceps strength paper]. 현재 표준 평가 도구인 등속성 근력 측정 장비(예: Biodex), 3차원 광학식 동작 분석 시스템(optical motion capture, OMC), 지면반발력 측정판(force plate)은 높은 정밀도의 생체역학적 데이터를 제공하지만, 구조적으로 특수 실험실 환경에 국한되어 있고, 전문 인력과 고비용을 요구하며, 일상적인 임상 모니터링에는 현실적으로 적용하기 어렵다. 그 결과, 대다수의 ACLR 환자들은 자신의 동작 품질에 대한 지속적이고 객관적인 평가 없이 재활 과정을 경과하게 되어, 임상 평가와 실제 기능 회복 사이에 심각한 괴리가 발생한다.

---

보행은 일상생활에서 가장 기본적이고 빈번하게 수행되는 이동 동작으로, 건강한 성인은 하루 평균 6,000–12,000보를 축적한다 [REF: Lisee 2022]. ACLR 환자에게 이러한 반복적이고 누적적인 기계적 노출은 보행을 모니터링의 핵심 대상이자 동시에 위험 인자로 만든다. 생체역학적 근거는 ACLR 환자들이 부하 반응기(loading response) 동안 무릎 굴곡각 감소, 최대 무릎 신전 모멘트(knee extension moment, KEM) 저하, 재건 측 수직 지면반발력(vertical ground reaction force, vGRF) 감소를 특징으로 하는 '무릎 경직(stiffened knee)' 전략을 채택한다는 것을 일관되게 보여준다 [REF: Lewek 2002; Di Stasi 2012; Yu 2026]. 특히 주목할 점은, 이러한 보행 보상 패턴이 단기적인 급성 반응에 머물지 않는다는 것이다. Büttner et al. [REF: Büttner 2024]은 수술 전부터 수술 후 12개월에 이르는 종합적인 양측 파형 분석을 통해 비정상적인 보행 역학이 비손상 측 하지에서도 지속됨을 확인하였으며, 이는 ACL 손상이 하지 운동 패턴 전반에 미치는 전신적·양측성 영향을 명확히 보여준다. 이러한 사실은 보행 정상화가 증상 해소와 별개로 독립적인 재활 목표 지표로 설정되어야 함을 시사한다.

---

비정상적인 보행 역학의 임상적 중요성은 장기적인 관절 퇴행과의 연관성으로 인해 더욱 증폭된다. Lisee et al. [REF: Lisee 2022]은 ACLR 후 일일 보행 수가 낮은 환자군(하루 3,326–6,042보)이 체중 수용 단계에서 현저히 낮은 vGRF와 KEM을 보인다는 것을 입증하였다. 이 두 지표는 금표준인 force plate 없이는 직접 측정이 불가능하나, IMU 기반 운동학(kinematics)으로 간접 대변될 수 있다는 근거가 축적되고 있다. Sigward et al.의 연구는 IMU로 측정된 경골(shank)의 낮은 각속도가 KEM 감소와 직접적으로 연관됨을 확인하였으며 [REF: Mpaliotes 2022], 이는 보행 중 두 번째 발구름 단계에서 경골 전방 회전 속도가 사두근 수축에 의한 최대 KEM과 동기화된다는 생체역학적 기전에 근거한다. Jones et al. [REF: sensors2209286]은 경골 부착 IMU의 각속도·선가속도와 무릎 모멘트 변화량, 무릎 가동범위, 무릎 강성 사이의 강한 상관관계(rs = 0.712–0.776)를 입증하며, IMU 파생 지표가 무릎 역학 변수의 유효한 대리 측정치(proxy measure)가 될 수 있음을 제안하였다. 나아가 Krishnakumar et al. [REF: EstimationReview]의 체계적 고찰은 IMU 기반 알고리즘이 보행 중 vGRF와 무릎 굴곡-신전 모멘트를 임상적 유의 차이(clinical difference) 이하의 RMSE로 추정 가능한 다수의 연구를 종합하였으며, Lee et al.은 천골 단일 IMU만으로 보행 중 3차원 하지 운동역학 데이터 추정이 가능함을 실증하였다 [REF: EstimationReview]. 이러한 근거들은 IMU 기반 운동학 시계열이 vGRF 및 KEM으로 대표되는 관절 부하 지표의 간접적 정보를 내포하고 있음을 시사한다. 더불어 이 적응 반응은 단순히 무해한 보상이 아니다. 무릎 내전 모멘트(KAM)와 굴곡 모멘트의 지속적 감소는 수천 번의 일일 반복 부하 사이클에 걸쳐 연골 접촉 응력 분포를 변화시키고, 연골 세포의 대사를 저해하며, 궁극적으로 PTOA 발생의 초기 구조적 신호로 인식된다 [REF: Gait post-ACLR OA perspective]. 역설적으로, 손상 초기에 전두면 관절 부하를 과도하게 감소시킨 환자들은 5년 추적 관찰에서 오히려 더 높은 OA 발생률을 보이는 것으로 나타나, 손상 유발 보행 보상 전략에서 연골 퇴행에 이르는 기계론적 연쇄가 확립된다 [REF: KAM paper]. 이러한 맥락에서 보행은 다른 기능적 평가들에 비해 결정적인 실용적 이점을 갖는다. 홉, 점프, 달리기 등의 고강도 과제가 재활 초기에 금기시되는 것과 달리, 보행은 저강도의 보편적으로 접근 가능한 활동으로서 회복 최초 단계부터 안전하게 평가될 수 있으며, 이는 전 재활 기간에 걸친 지속적·종단적 모니터링의 이상적인 매개체가 된다.

---

ACLR 관련 보행 병리의 특히 중요하고 간과되어 온 특성 중 하나는 **속도 의존성**이다. Garcia et al. [REF: Garcia 2021]은 ACLR 환자에서 보행 속도가 증가함에 따라(자기선택 속도의 80% → 100% → 120%) 수직 및 전후 방향 지면반발력의 좌우 비대칭이 진행적으로 증가하는 반면, 건강한 대조군에서는 속도 변화에 따른 비대칭 변화가 미미함을 입증하였다. Krishnan et al. [REF: Krishnan 2022]도 이를 재확인하며, 자기선택 속도에서의 평가가 거의 정상에 가까운 대칭 지수를 산출할 수 있음을 보였다. 이는 기저의 신경근 결손을 위장하는 거짓 안심을 초래하는 반면, 빠른 속도에서만 보행 기능 장애의 실제 범위가 드러난다는 것을 의미한다. 실제로 Krishnan et al.은 ACLR 수술 후 6개월 시점에서 자기선택 속도 보행 시 수직 GRF의 좌우 차이가 체중 대비 5% 미만으로 '정상 범위'에 근접한다는 선행 연구들을 인용하면서, 이러한 결과가 보행 비대칭의 해소를 의미하는 것으로 해석되어서는 안 된다고 명시적으로 경고하였다. 이는 비손상 측 GRF의 동반 감소로 인해 두 지체 간 차이가 인위적으로 축소되는 현상일 수 있기 때문이다 [REF: Krishnan 2022]. Garcia et al. 역시 ACLR 환자들이 가장 느린 속도(80%)에서는 GRF 변조가 가장 작고 좌우 대칭성이 가장 높게 나타나는 반면, 빠른 속도에서는 재건 측 하지의 GRF 파형 전반이 '완만하게 눌린(blunted)' 형태를 보이며 이는 재부상에 대한 공포 또는 수행 과제의 요구 증가에 따른 적응적 언로딩 전략을 반영한다고 보고하였다 [REF: Garcia 2021]. 나아가 Yu et al.은 이러한 이상 소견들이 일상적인 임상 평가 또는 자기선택 보행 속도에서는 포착되기 어려우며, 빠른 보행과 같은 고수요 과제에서 비로소 현저하게 나타남을 강조하였다 [REF: Yu 2026]. Lai et al. [REF: Lai 2024]은 이 관찰을 3차원 운동학으로 확장하여, 빠른 보행 속도에서만 나타나는 횡단면 비대칭(외회전 증가, 근위부 경골 전방 이동)을 확인하였다. 이러한 연구들은 단일 자기선택 속도에서의 평가가 ACLR 후 보행 기능 장애의 전체 스펙트럼을 파악하는 데 구조적으로 불충분함을 공통적으로 시사한다. 다속도(multi-pace) 평가는 편안한 속도에서는 은폐되는 보상 전략을 노출시키기 위해 생체역학적으로 필수적이다.

---

착용형 관성 측정 장치(inertial measurement unit, IMU)는 실험실 수준의 생체역학적 평가와 실제 임상 적용 가능성 사이의 간극을 좁히는 유망한 기술로 주목받고 있다. IMU는 소형이며 저렴하고 휴대 가능하여, 통제된 환경 밖에서도 연속적인 3차원 동작 측정을 가능하게 한다 [REF: Yona 2026; EstimationReview]. 최근 연구에 따르면 IMU 기반의 보행 파라미터는 보행 과제에서 금표준인 광학식 동작 분석 시스템과 비견할 만한 정확도를 보이며 [REF: Yona 2026], IMU 데이터에 기계학습(ML) 모델을 적용한 결과 통제된 환경에서 95% 이상의 정확도로 ACLR 결과를 분류하는 데 성공한 바 있다 [REF: Zhu 2025]. 그러나 기존 문헌에는 여전히 치명적이고 구조적인 공백이 존재한다. 첫째, 대부분의 IMU 기반 ACL 연구는 **횡단면적(cross-sectional)** 설계로, 회복 궤적을 종단적으로 추적하지 못하고 단일 시점의 측정에 그친다. 둘째, 대부분의 접근법은 **단일 보행 속도** 프로토콜을 채택하여, 앞서 제시한 생체역학적 근거가 임상적으로 필수적이라고 확인한 속도 의존적 비대칭 증폭 현상을 포착하지 못한다 [REF: Garcia 2021; Krishnan 2022]. 셋째, 기존의 ML 파이프라인 대부분은 이산적(discrete) 스칼라 지표를 추출하는 특징 공학(feature engineering)에 의존하며, 구체적으로는 시간 영역에서의 평균 가속도, 최대 각속도, 제곱평균제곱근(RMS), 표준편차, 첨도, 왜도, 피크-투-피크 진폭, 사분위 범위(IQR), 신호에너지 등이 사용되어 왔으며 [REF: sensors2003029; Zhu 2025], 주파수 영역에서는 푸리에 변환 또는 웨이블릿 변환으로부터 도출된 파워 스펙트럼 밀도(PSD), 지배 주파수, 스펙트럼 중심, 고조파 비율(harmonic ratio) 등이 주요 입력 특징으로 활용되었다 [REF: Zhu 2025; sensors2003029; Yuan 2026]. 나아가 시공간 파라미터 기반 접근에서는 보행 주기 시간, 입각기 및 유각기 지속 시간, 보장(step length), 케이던스(cadence) 등의 이산 지표가 ML 입력으로 사용되었다 [REF: Parola et al.]. 이처럼 이산적 특징들은 보행의 전반적 특성을 요약하는 데 일정 수준의 유용성을 가지지만, 보행 주기 전반에 걸친 IMU 신호 파형의 풍부한 시간적 구조를 충분히 활용하지 못한다. 이 점과 관련하여 Büttner et al. [REF: Büttner 2024]은 피크값 중심 분석의 구조적 한계를 다음과 같이 명시적으로 지적하였다. 해당 연구는 보행 입각기 전체에 걸친 vGRF, 무릎 굴곡각(KFA), KEM, KAM의 파형 분석을 수행하면서, 기존 연구들이 입각기 전반부의 피크값에 집중해 온 것과 달리, 재건 측과 대조군 간의 유의미한 차이가 중간 입각기(midstance)의 vGRF 파형 및 초기~후기 입각기의 KFA 전반에 걸쳐 광범위하게 존재함을 확인하였다. 특히 "입각기 첫 번째 피크 이외의 구간이 ACLR 이후 KOA 발생과 연관된 연골 변화를 예측하는 데 오히려 더 강력한 지표일 수 있다"고 명시하며 [REF: Büttner 2024], 입각기 전반부의 피크값만을 평가하는 접근은 임상적으로 잘못된 해석을 초래할 수 있다고 결론지었다. 임상적으로 의미 있는 미세한 이상을 내포하는 것은 보행 역학의 전체 시계열 궤적이며, 피크값 요약 통계는 이를 포착하기에 근본적으로 불충분하다.  현재 선행 연구 조사 결과로는, **다속도 IMU 보행 시계열 분석과 기계학습을 결합하여 ACLR 환자 판별과 종단적 회복도 추적을 동시에 수행한 연구는 현재까지 존재하지 않는다**. 이것이 바로 임상 현장이 가장 시급하게 요구하는 조합이다.

---

본 연구는 착용형 IMU 센서로 수집한 다속도 지상 보행 데이터와, 보행 주기 전체 시계열에 작동하는 기계학습 모델을 결합하는 프레임워크를 제안함으로써 이 공백을 해소하고자 한다. 구체적으로 본 연구의 목적은 다음과 같다: (1) 다속도 IMU 보행 시계열 데이터를 활용하여 ACLR 환자와 건강한 대조군을 감별하는 ML 모델을 개발하고 검증한다; (2) 속도 의존적 보행 비대칭을 회복 상태의 동적 지표로 정량화한다; (3) IMU 기반 보행 특징의 전 재활 단계에 걸친 종단적 회복 지표로서의 적용 가능성을 평가한다. 일상생활에서 가장 생태학적으로 타당하고, 보편적으로 접근 가능하며, 임상적으로 실현 가능한 운동 과제인 '일상 보행'에 환자 평가의 기반을 두고, 다속도 조건에 걸친 IMU 신호의 완전한 시간적 풍부성을 활용함으로써, 본 연구는 비침습적·저비용·확장 가능한 객관적 ACLR 재활 모니터링 및 스포츠 복귀 의사 결정 지원 체계의 기반을 마련하고자 한다.

---

**[REF] 인용 목록 (최종 번호 삽입 전 확인용)**

| 위치 | 해당 논문 |
| --- | --- |
| [REF: Zhu 2025] | Zhu et al., Smart Health, 2025 |
| [REF: Yu 2026] | Yu et al., Orthopaedic Surgery, 2026 |
| [REF: Büttner 2024] | Büttner et al., J Orthop Res, 2024 |
| [REF: Garcia 2021] | Garcia et al., J Orthop Res, 2021 |
| [REF: Krishnan 2022] | Krishnan et al., J Orthop Res, 2022 |
| [REF: Lai 2024] | Lai et al., Orthopaedic Surgery, 2024 |
| [REF: Lisee 2022] | Lisee et al., Med Sci Sports Exerc, 2022 |
| [REF: Yona 2026] | Yona et al., Scientific Data, 2026 |
| [REF: Di Stasi 2012] | Di Stasi et al. (RTS gait patterns) |
| [REF: Lewek 2002] | Lewek et al. (quadriceps strength & gait) |

==================================================
[데이터셋: COMPWALK-ACL (Yona et al., 2026, Scientific Data)]
==================================================

사용할 데이터 그룹 구성:
  - ACLD: ACL 손상(수술 전) 27명
  - ACLR: ACL 재건술 후 3개월 27명 (ACLD와 동일 피험자 → 종단 쌍)
  - Healthy Adults: 건강한 성인(18–45세) 25명
  - 총 79명

이 데이터셋의 핵심 가치 (반드시 슬라이드에 강조):
  - 동일 피험자의 수술 전후 데이터를 모두 포함하는 
    세계 유일의 공개 다속도 IMU 보행 데이터셋
  - 종단 쌍(longitudinal pair) 설계
  - 다속도(Slow / Normal / Fast) 조건이 포함되어 있어, 
    속도 의존적 비대칭 증폭 현상 검증 가능

센서 구성:
  - 총 693개 IMU 채널 (orientation, position, velocity, jointAngle 등)
  - 23개 segment: Xsens 모델이 계산한 segment-level kinematics
  - 7개 실측 IMU 센서: pelvis, L/R thigh, L/R shank, L/R foot
  - 분석 주요 대상은 7개 실측 IMU 신호

보행 조건:
  - 3가지 속도: Slow / Normal / Fast (self-selected 기준)
  - 지상 보행(overground walking)

==================================================

==================================================
[방법론: 3단계 파이프라인 — 레퍼런스 완비본]

각 단계별로 슬라이드에 "WHY(왜 이 방법인가)"를 반드시 명시해 주세요.
각 근거 뒤에는 [저자 연도] 형태로 출처를 표기했습니다.

─────────────────────────────────────────────────
STEP 1-① 파형 분석 스트림: SPM1D
─────────────────────────────────────────────────

분석 내용:

- stance 구간 101pt 시간 정규화 후 평균 파형 생성
- knee_flexion, 9채널 × 3속도 조건 SPM1D ANOVA (group × speed 상호작용)
- 27쌍 ACLD–ACLR Paired t-test (종단 수술 전후 비교)
- Top-5 유의 구간 특징 LMM(선형혼합모형)

WHY SPM1D — 근거 3중 구조:

근거 1) 피크값만으로는 임상적으로 중요한 구간이 누락됨
Büttner et al. (2024, J Orthop Res)는 수술 전~수술 후 12개월의
종단 파형 분석에서, 입각기 내 집단 간 차이가 "전반부 피크"에만
존재하는 것이 아니라 중간 입각기(midstance) vGRF와 초기~후기
입각기 KFA 전 구간에 걸쳐 광범위하게 분포함을 확인하였다.
특히 중간 입각기 하중이 12개월 시점의 연골 변화를 피크 vGRF보다
더 강력하게 예측함을 보였다.
→ "only evaluating peak outcomes within the first half of stance
may lead to poor interpretations of results" [Büttner et al., 2024]

근거 2) SPM1D는 ACL 보행 속도 연구의 방법론적 표준
Garcia et al. (2021, J Orthop Res)은 80%/100%/120% 자기선택
속도별 수직·전후 GRF의 비대칭을 비교할 때 SPM1D 2×3 반복측정
ANOVA를 사용하여, 단일 시점 비교로는 포착 불가능한 stance
전 구간에 걸친 속도×집단 상호작용을 확인하였다.
같은 방법론을 Krishnan et al. (2022, J Orthop Res)도 동일하게
적용하며, "SPM1D는 단일 이산 시점 사용 시 포착되지 않을 수 있는
보행 특성의 더 강건한 평가를 제공한다"고 명시하였다.
[Garcia et al., 2021; Krishnan et al., 2022]

근거 3) 다속도 3D 운동학 비교에서도 SPM1D 적용 선례 확립
Lai et al. (2024, Orthopaedic Surgery)는 Slow/Normal/Fast 3가지
속도 조건의 ACLR 무릎 운동학 비교에 SPM1D paired t-test를
적용하여, 빠른 속도에서만 나타나는 횡단면 비대칭을 파형 수준에서
검출하였다. 이는 본 연구의 분석 설계와 직접 대응된다.
[Lai et al., 2024]

─────────────────────────────────────────────────
STEP 1-② 스칼라 분석 스트림: ANOVA / LMM
─────────────────────────────────────────────────

분석 내용:

- stance 구간별 peak / min / ROM / IC_angle / peak_timing 추출
→ features_scalar.csv (148 features)
- 비대칭 지표(LSI: Limb Symmetry Index) 추가 산출
- Shapiro-Wilk 정규성 검정 → ANOVA / Kruskal-Wallis
- 효과 크기 산출: η² (집단 간) + Cohen's d (쌍별 비교) → 특징 ranking
- Ranking plots, LSI box plots 시각화

WHY 스칼라 분석 — 근거 3중 구조:

근거 1) 기존 임상 표준 지표의 재현 및 데이터 유효성 검증
Kokkotis et al. (2022, Scientific Reports)은 ACLD/ACLR/CON
3집단에서 무릎 굴곡각(KFA), 무릎 신전 모멘트(KEM), GRF 등
21개 스칼라 생체역학 지표를 ANOVA로 사전 선별한 후 SVM 모델에
투입하여 94.95%의 분류 정확도를 달성하였다. 이 연구는 스칼라
통계 분석이 데이터셋의 임상 타당성을 확인하는 표준 절차임을 보여준다.
[Kokkotis et al., 2022]

근거 2) LSI는 ACLR 회복도의 핵심 임상 벤치마크
수술 후 재활 과정에서 LSI는 RTS(return to sport) 결정의 핵심
기준으로 사용되어 왔으며 [sensors2505837 systematic review, 2025],
Mpaliotes(2022) 체계적 고찰에서 검토된 5개 연구 모두 ACLR 측의
peak KEM, peak vGRF, shank angular velocity 등의 스칼라 좌우
비대칭 지표가 건강 대조군 대비 유의하게 작음을 공통적으로
보고하였다. 그러나 시공간 파라미터(cadence, stride length 등)는
ACLR과 건강군을 구별하기에 부적합하다는 점도 확인되었다.
→ "Spatiotemporal variables are not suitable parameters to
distinguish knee gait biomechanics of ACLR subjects from
healthy ones" [Mpaliotes, 2022; Leporace et al., 2016 인용]

근거 3) 효과 크기 기반 ranking은 소규모 임상 ML의 표준 전처리
Hart et al. (2015, Br J Sports Med)의 메타분석은 ACLR 후 시간에 따른
생체역학 변수들의 Cohen's d를 체계적으로 보고하여, peak KFA,
KEM, KAM이 집단 간 가장 큰 효과 크기를 가짐을 확인하였다.
이러한 효과 크기 기반 특징 ranking은 소규모 샘플(n=79)에서
ML 과적합을 방지하기 위한 domain-knowledge 사전 선별의 근거로
기능한다. Kokkotis et al. (2022)도 151명의 데이터에서 특징 수를
점진적으로 늘릴수록 ML 정확도가 향상되다가 21개 최적 특징에서
최고 성능에 수렴함을 실증하였다.
[Hart et al., 2015; Kokkotis et al., 2022]

─────────────────────────────────────────────────
STEP 1 → STEP 2 브릿지 슬라이드
(방법론 정당화의 핵심 — 반드시 독립 슬라이드로 구성)
─────────────────────────────────────────────────

전달 메시지:
"통계 분석은 '무엇이 다른가'를 집단 수준에서 확인합니다.
ML은 '그 차이로 실제 개인 분류가 가능한가'를 증명합니다.
그리고 SHAP는 '통계가 보지 못한 새로운 패턴'을 발견합니다."

브릿지 논거 — 레퍼런스 완비:

논거 1) 통계 선별 특징이 ML 성능을 최적화
Kokkotis et al. (2022, Scientific Reports)은 전체 특징 공간에서
ANOVA 유의성 기반 특징 선별 후 SVM에 투입하는 순차 파이프라인을
설계하여, 특징 수가 증가할수록 분류 정확도가 향상되다가
통계 유의 특징 중심의 21개에서 94.95%로 수렴하는 패턴을 확인하였다.
이는 통계 기반 사전 선별이 ML 성능을 보존하는 최적 전략임을 실증한다.
[Kokkotis et al., 2022]

논거 2) SHAP가 통계 분석을 '넘어서는' 특징을 발견
Kokkotis et al. (2022)은 SHAP 분석 결과를 통계 ANOVA 결과와 교차
비교하여, "통계 분석으로는 무시되었을 특징들이 ML 모델 출력에
유의미한 영향을 미치는 기여 파라미터로 확인되었다"고 명시하였다.
→ "Features that would have been neglected by the traditional
statistical analysis were identified as contributing parameters
having significant impact on the ML model's output"
즉 SHAP는 통계 분석의 대체가 아닌 확장이며, 두 방법이 상호
검증(cross-validation) 관계를 형성한다.
[Kokkotis et al., 2022]

논거 3) 소규모 임상 데이터에서 통계 사전 선별의 필요성
Kokkotis et al. (2023, IJERPH)의 체계적 고찰은 무릎 수술 환자
ML 연구들의 주요 한계로 "소규모 피험자 수, 부적절한 특징 선별"을
지목하며, "강건한 특징 선별 기법과 XAI를 결합하여 그 결과를
ML 모델의 입력으로 사용해야 한다"고 명시적으로 권고하였다.
→ "Future works should use robust feature selection techniques
and advanced AI. This knowledge can be the input for
powerful ML models." [Kokkotis et al., 2023, IJERPH]
본 연구의 총 피험자 79명은 바로 이 소규모 임상 데이터 시나리오에
해당하며, 통계 선별 → ML 투입 파이프라인은 해당 권고사항의 직접
구현이다.

─────────────────────────────────────────────────
STEP 2: ML 분류 + SHAP 해석
─────────────────────────────────────────────────

분류 목표: ACLD / ACLR / Healthy 3-class 판별
+ ACLD vs ACLR 이진 분류 (회복도 추적 핵심)

ML 설계 근거:

근거 1) 3-class 설계 선례
Kokkotis et al. (2022, Scientific Reports)은 ACLD/ACLR/CON
동일한 3집단 구조에서 SVM 94.95%, Neural Network 92.89%를
달성하였으며, 본 연구는 이 설계를 IMU 원시 신호 기반으로
확장한다. [Kokkotis et al., 2022]

근거 2) IMU 기반 ACLR 분류의 최고 성능 벤치마크
Zhu et al. (2025, Smart Health)은 손목·발목·천골 5개 IMU의
PSI(Phase Slope Index) 행렬 특징으로 KNN 96.37%의 정확도를
달성하였다. 또한 모델 신뢰도(confidence)가 회복 기간과 강하게
상관됨을 t-SNE로 시각화하여, ML 모델이 회복도 추적 도구로
기능할 수 있음을 최초로 입증하였다.
→ 본 연구의 종단(ACLD→ACLR) 설계는 이 발견의 직접적 검증이다.
[Zhu et al., 2025]

근거 3) Leave-One-Subject-Out CV 적용 (소규모 샘플 대응)
Kokkotis et al. (2023, IJERPH) 체계적 고찰에서 검토된 연구들이
공통적으로 소규모 피험자에서의 외부 검증 부재를 한계로 지적하였다.
본 연구는 피험자 독립적 교차검증(LOSO-CV) 또는 이에 준하는
방식으로 이 한계를 직접 해소한다. [Kokkotis et al., 2023]

SHAP 해석 설계 근거:

근거 1) ACL 분야 ML의 "black box" 문제 해결 필요성
Zhu et al. (2025)은 기존 ML 파이프라인들이 "black box 특성으로
인해 임상 번역에 장벽이 된다"고 지적하였다.
[Zhu et al., 2025]

근거 2) SHAP의 ACL 3-class 분류 적용 검증 선례
Kokkotis et al. (2022)은 ACLD/ACLR/CON 3개 이진(one-vs-one)
SVM 모델 각각에 SHAP를 적용하여 집단별로 기여 특징이 다름을
확인하였다. CON vs ACLD에서는 H4(고관절 변수)가, CON vs ACLR
에서는 K2(무릎 변수)가 최우선 기여 특징으로 확인되었으며,
이는 집단별 재활 목표 특이성을 반영한다.
[Kokkotis et al., 2022]

근거 3) SHAP와 통계 분석의 상호 검증이 임상 신뢰도를 높임
Kokkotis et al. (2022)은 SHAP 상위 특징에 대해 ANOVA를 재적용하여
"SHAP가 중요하다고 식별한 특징들이 모든 비교에서 통계적으로도
유의한 집단 간 차이를 보였다"고 보고하였다. 이 교차 검증 구조가
본 연구 파이프라인의 임상 신뢰도의 핵심이다.
[Kokkotis et al., 2022]

==================================================
[방법론 섹션 레퍼런스 요약 — 슬라이드 각주용]

SPM1D 근거:

- Büttner et al. (2024) J Orthop Res — 전 파형 분석의 우월성
- Garcia et al. (2021) J Orthop Res — SPM1D 2×3 ANOVA 선례
- Krishnan et al. (2022) J Orthop Res — 이산 시점의 한계 명시
- Lai et al. (2024) Orthopaedic Surgery — 다속도 SPM1D 선례

스칼라 분석 근거:

- Kokkotis et al. (2022) Scientific Reports — 스칼라→ML 파이프라인
- Hart et al. (2015) Br J Sports Med — 효과 크기 기반 지표 ranking
- Mpaliotes (2022) thesis — LSI 및 시공간 변수의 한계 명시
- sensors2505837 (2025) Sensors — LSI 임상 표준 확인

통계→ML 브릿지 근거:

- Kokkotis et al. (2022) Scientific Reports — 통계 선별 → ML 성능 수렴
- Kokkotis et al. (2023) IJERPH — 소규모 데이터 특징 선별 권고
- Kokkotis et al. (2022) — SHAP가 통계 누락 특징 발견

ML + SHAP 근거:

- Kokkotis et al. (2022) Scientific Reports — 3-class SHAP 선례
- Zhu et al. (2025) Smart Health — IMU 기반 96% 분류, 회복도 추적
- Kokkotis et al. (2023) IJERPH — 외부 검증 부재 한계 지적

==================================================
[현재까지 결과 (STEP 1 완료)]
==================================================

  - 스칼라 분석: 속도별 경향성 시각화, 
    effect size(η², Cohen's d) 기준 특징 ranking 완료
  - 핵심 발견 3가지를 수치와 함께 제시할 것
    (내용은 작성자가 실제 결과를 채워 넣을 위치)
  - 이 결과가 STEP 2 ML 입력으로 어떻게 연결되는지 브릿지 설명 포함

==================================================
[앞으로 할 것 (STEP 2, 3)]
==================================================

  - ML 학습 및 검증 (분류 모델 구축)
  - SHAP 기반 특징 해석 및 통계 결과와 비교
  - 예상 산출물: 혼동 행렬, SHAP beeswarm, 속도별 분류 성능 비교 그래프

==================================================
[핵심 문헌 (슬라이드 근거로 활용)]
==================================================

  - Garcia et al., 2021, J Orthop Res: 속도 증가 시 GRF 비대칭 증폭
  - Krishnan et al., 2022, J Orthop Res: 자기선택 속도의 거짓 대칭 문제
  - Lai et al., 2024, Orthopaedic Surgery: 빠른 속도에서만 횡단면 비대칭 노출
  - Büttner et al., 2024, J Orthop Res: 피크값만으로는 불충분, 
    전체 파형 분석 필요, 비손상 측에서도 비정상 보행 지속
  - Lisee et al., 2022, Med Sci Sports Exerc: 일일 보행 수 감소 → 
    관절 언더로딩 → 연골 퇴행
  - Zhu et al., 2025, Smart Health: IMU+ML로 ACLR 분류 95% 정확도, 
    XAI 필요성
  - Yona et al., 2026, Scientific Data: COMPWALK-ACL 데이터셋 소개
  - Jones et al., 2022, Sensors: IMU 각속도/가속도가 무릎 모멘트의 
    proxy measure로 기능함을 실증