# 0529 교수님 미팅용 HTML 발표 자료 제작 계획

## Summary
- 새 발표 자료를 `PT/0529최현수교수님/aclr_meeting_slides.html`로 만든다.
- 형식은 16:9 HTML 슬라이드, 큰 글자, 텍스트 최소화, 시각화 중심으로 구성한다.
- 통계 결과는 `data/processed/*.csv` 최신 결과를 기준으로 사용한다.
- `GAI 중간 결과/statistics_v1.html`은 section 2.6.1까지의 통계 방법 설명을 고도화하는 참고 자료로만 사용한다.
- `htmls/statistical_methods.html`의 그림 13 흐름도는 현재 통계 로직에 맞게 고도화한다.
- 모든 핵심 주장에는 각주를 달고, 마지막 슬라이드에 참고문헌을 정리한다.

## Subagent Split
- **Literature Agent**
  - `intro.md` 기반 선행연구를 정리하고 모델 선정 근거를 보완한다.
  - Logistic Regression, SVM/RBF, Random Forest, Gradient Boosting, CNN1D, Transformer, RNN 선정 근거를 문헌 기반으로 요약한다.

- **Statistics/Data Agent**
  - 최신 `stats_results.csv`, `spm_results.csv`, `spm_paired_results.csv`에서 발표용 표와 요약 수치를 추출한다.
  - 유의도 정렬표, 속도별 유의 feature 요약, SPM 유의 구간 요약을 만든다.

- **Visualization/Slide Agent**
  - 큰 글자와 시각화 중심의 16:9 HTML 슬라이드 초안을 만든다.
  - 기존 그림과 inline SVG/막대그래프/흐름도를 조합한다.

- **Main Agent**
  - 최종 HTML 통합, 각주/참고문헌 정렬, Playwright 검증을 담당한다.
  - `htmls/statistical_methods.html` 그림 13도 같은 통계 흐름으로 수정한다.

## Key Changes
- 슬라이드 구조는 20장으로 구성한다.
- 레이아웃은 기존 `PT/0527 랩미팅/0527_slides.html`의 로컬 HTML 슬라이드 방식을 계승하되, 더 큰 폰트와 시각 자료 중심으로 재작성한다.
- 외부 CDN 의존 없이 로컬에서 바로 열리는 단일 HTML로 만든다.
- 필요한 기존 그림은 `harness/figures`, `artifacts`, `PT/0527 랩미팅`에서 참조하고, 부족한 시각화는 HTML 내 inline SVG/표/막대그래프로 직접 생성한다.
- 통계 흐름도는 muted blue/gray 계열로 통일하고, 노드에서 `step~` 표기는 제외한다.

## Slide Plan
1. **Title**
   - IMU 기반 다속도 보행 분석을 통한 ACLD/ACLR/HA 분류 및 ML 프레임워크

2. **오늘 보고 흐름**
   - 진행상황 → 선행연구 → 통계 분석 방법 → 통계 결과 → 연구 목표 고도화 → ML 베이스라인

3. **연구 배경: ACLR 이후에도 남는 임상 부담**
   - 재파열, PTOA, RTS 판단 한계를 숫자 카드로 표현
   - 각주: Zhu 2025, Yu 2026, Kaur 2016, Di Stasi 2013

4. **왜 보행인가**
   - 하루 보행 노출, stiffened-knee 전략, KEM/vGRF proxy 논리를 도식화
   - 각주: Lewek 2002, Lisee 2022, Jones 2022

5. **선행연구 핵심 1: fast gait가 숨은 비대칭을 드러냄**
   - slow/normal/fast 조건에서 비대칭이 증가하는 개념 그림
   - 각주: Garcia et al. 2022, Lai et al. 2024

6. **선행연구 핵심 2: peak만으로는 부족함**
   - peak scalar vs full waveform 비교 그림
   - 각주: Büttner et al. 2024, SPM1D 근거

7. **선행연구 핵심 3: IMU + ML의 가능성과 공백**
   - “가능한 것”과 “아직 부족한 것”을 2열 비교
   - 각주: Kokkotis et al. 2022, Zhu et al. 2025, Yona et al. 2025

8. **현재 연구 목표 H1/H2/H3**
   - `GAI 중간 결과/intro.md`의 가설을 유지하되 발표용 문장으로 압축
   - H1: 3군 분류
   - H2: multi-speed 우월성
   - H3: waveform/DL 입력의 추가 정보 가능성

9. **데이터 구조**
   - ACLD 27 / ACLR 27 / HA 25, 3속도, 9채널, 양측 구조를 한 장의 인포그래픽으로 표현

10. **harness 통계 분석 파이프라인**
   - `htmls/statistical_methods.html` 그림 13을 참고하되 최신 로직으로 수정
   - Scalar features → 정규성 검정 → 등분산 검정 → ANOVA/Welch/Kruskal → post-hoc → FDR-BH → 효과크기 → ML 후보 feature
   - 노드에 step 번호는 쓰지 않음

11. **통계 방법: waveform stream**
   - SPM1D ANOVA와 paired t-test 흐름
   - `statistics_v1.html` 2.6.1의 논리를 발표용으로 압축
   - 수식은 작게, 101-point gait cycle 그림을 크게

12. **통계 방법: scalar stream**
   - peak/min/ROM/IC_angle/peak_timing/LSI 추출 구조
   - Shapiro-Wilk + Levene 기반 분기:
     - 정규성 통과 + 등분산 통과: One-way ANOVA + Tukey HSD
     - 정규성 통과 + 등분산 실패: Welch ANOVA + Games-Howell
     - 정규성 실패: Kruskal-Wallis + Mann-Whitney U + Bonferroni
   - 모든 omnibus p-value는 FDR-BH 보정

13. **통계 결과 1: 유의도 기준 정렬표**
   - 최신 `data/processed/stats_results.csv` 기준
   - p_adj 오름차순 상위 유의 feature 표
   - 컬럼: feature, speed, method, p_adj, eta2, 주요 해석

14. **통계 결과 2: 속도별 유의 feature 요약**
   - fast/normal/slow 3개 패널
   - 현재 CSV 기준: fast 10개, slow 5개, normal 4개
   - fast 조건에서 유의 feature가 가장 많다는 메시지 시각화

15. **통계 결과 3: knee 중심 결과**
   - knee_flexion_peak_LSI, knee_flexion_asym, knee_flexion_ROM_injured 강조
   - 기존 `boxplot_knee_flexion_LSI.png`, ranking plot 활용

16. **통계 결과 4: SPM waveform**
   - fast knee flexion/adduction/internal rotation 유의 구간을 gait cycle timeline으로 표시
   - 최신 `spm_results.csv`: fast knee_adduction, knee_int_rotation, knee_flexion 유의
   - paired result는 normal knee_flexion 1개로 별도 표시

17. **연구 목표 고도화**
   - 통계 결과가 H1/H2/H3를 어떻게 뒷받침하는지 연결
   - fast gait, knee feature, waveform 정보의 의미를 요약

18. **ML 베이스라인 설계**
   - 목표: ACLD / ACLR / HA 3군 분류
   - 입력: scalar features, waveform flattened, raw/padded waveform
   - 모델: logistic regression, SVM/RBF, random forest, gradient boosting 계열, CNN1D, Transformer, RNN 계열

19. **모델 선정 근거**
   - Logistic regression: 해석 가능한 baseline
   - SVM/RBF: Kokkotis et al.에서 ACL 3군 분류 최고 성능 보고
   - RF/Gradient boosting: tabular biomechanical feature baseline
   - CNN1D/RNN/Transformer: IMU/waveform 시계열 feature learning 확장
   - 각주: Kokkotis 2022, Zhu 2025, IMU gait ML/DL review 문헌

20. **평가 전략**
   - 메인 지표: multiclass AUC
   - 서브 지표: macro-F1
   - subject 기준 GroupKFold로 leakage 방지
   - 비교: single-speed vs multi-speed, scalar vs waveform

21. **교수님께 확인받을 사항**
   - H1/H2/H3 유지 타당성
   - 3군 분류를 1차 ML 목표로 두는 방향
   - baseline 모델 범위와 우선순위

22. **References**
   - 슬라이드 각주 번호와 연결되는 참고문헌 목록
   - `intro.md`의 확인 필요 문헌은 구현 시 웹/DOI로 검증 후 정리

## Literature Sources To Use
- Kokkotis et al. 2022, Scientific Reports: ACLD/ACLR/CON 3군 ML, SVM 최고 성능, SHAP 기반 feature 해석  
  https://www.nature.com/articles/s41598-022-10666-2
- Garcia et al. 2022, Journal of Orthopaedic Research: fast walking에서 ACLR gait asymmetry 악화  
  https://pubmed.ncbi.nlm.nih.gov/34101887/
- Büttner et al. 2024/2025, Journal of Orthopaedic Research: bilateral waveform analysis, peak 외 구간의 중요성  
  https://pmc.ncbi.nlm.nih.gov/articles/PMC11701409/
- Yona et al. 2025, Scientific Data: COMPWALK-ACL multi-pace IMU dataset  
  https://doi.org/10.1038/s41597-025-06307-8
- Zhu et al. 2025, Smart Health: IMU + explainable predictive modeling for ACL reconstruction classification  
  https://www.sciencedirect.com/science/article/abs/pii/S2352648325000364
- Lai et al. 2024, Orthopaedic Surgery: fast walking에서 ACLR kinematic asymmetry  
  https://pmc.ncbi.nlm.nih.gov/articles/PMC10984808/

## Test Plan
- HTML을 브라우저에서 열어 16:9 슬라이드가 넘김 방식으로 동작하는지 확인한다.
- Playwright로 데스크톱 viewport screenshot을 찍어 글자 크기, 겹침, 이미지 로딩을 확인한다.
- 표가 너무 작으면 상위 feature 수를 줄이고, 전체 표는 백업 슬라이드로 보낸다.
- 참고문헌 번호와 슬라이드 각주 번호가 일치하는지 확인한다.
- 최신 CSV 기준 유의 feature 개수와 속도별 개수가 슬라이드와 일치하는지 확인한다.

## Assumptions
- 결과 표는 최신 `data/processed/stats_results.csv`, `spm_results.csv`, `spm_paired_results.csv`를 기준으로 한다.
- `statistics_v1.html`의 “5개 유의 feature” 서술은 최신 결과와 다르므로 그대로 쓰지 않는다.
- `knee-only vs all lower-limb features` 실험은 제외한다.
- AUC를 메인 지표, macro-F1을 서브 지표로 제시한다.
- 발표 자료 생성 후 필요하면 한국어 커밋 메시지로 커밋한다.
